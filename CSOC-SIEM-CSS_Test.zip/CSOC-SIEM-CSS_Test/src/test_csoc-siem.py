'''
CSOC-SIEM-CSSが適用されるDOMを取得するプログラム
'''

from common import funcs
from common import validate
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver import Firefox, FirefoxOptions
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait # 待機時間の設定
from selenium.webdriver.support import expected_conditions as EC # 次にクリックしたページの状態をチェックする
from selenium.webdriver.common.by import By # htmlタグの取得
from selenium.webdriver.common.keys import Keys # Key入力
from selenium.webdriver.support.color import Color
import unittest
import os
import collections
import re
import glob
import logging
import logging.config


class ExtensionTest(unittest.TestCase):
    '''
    unittestの動き setUpClass　→（setUp → test~　→tearDown~）*ループ →　tearDownClass
    '''
    LoadConfig = funcs.loadInitFile()

    validate.config_validation(LoadConfig)
    opt = LoadConfig['env']['browser']
    hdl = LoadConfig['env']['headless']

    Idaten_User = LoadConfig['Idaten']['user']
    Idaten_Pass = funcs.decoded(LoadConfig['Idaten']['password'])
    Idaten_Url = LoadConfig['Idaten']['url']
    Qrader_User = LoadConfig['Qrader']['user']
    Qrader_Pass = funcs.decoded(LoadConfig['Qrader']['password'])

    # NOTE:testurllist
    Url_List = [lst for lst in LoadConfig if "Test" in lst]
    
    @classmethod
    def setUpClass(cls):
        logging.info("+++開始")

    def setUp(self):
        logging.info("+++全体前処理")
        if self.opt == "Firefox":
            browserPath = self.LoadConfig['Firefox']['prog']
            WebDriver = self.LoadConfig['Firefox']['webdriver']
            Ext_RootPath = self.LoadConfig['Firefox']['ext_path']
            Ext_Type = self.LoadConfig['Firefox']['type']
            # NOTE:SOC環境におけるFirefoxの標準プロファイル生成
            profile = webdriver.FirefoxProfile()
            profile.set_preference('security.enterprise_roots.enabled', 'true')
            profile.set_preference('xpinstall.signatures.required', 'false')
            profile.set_preference('security.enterprise_roots.enabled', 'true')
            profile.set_preference('general.config.filename', 'csoc.cfg')
            profile.set_preference('general.config.vendor', 'csoc')
            profile.set_preference('general.config.obscure_value', 0)
            # NOTE:証明書の警告を無視する
            profile.accept_untrusted_certs = True
            profile.assume_untrusted_cert_issuer = False
            
            options = FirefoxOptions()

            if self.hdl:
                options.add_argument('-headless')

            try:
                self.driver = webdriver.Firefox(service_log_path=os.path.devnull, firefox_binary=browserPath,executable_path=WebDriver, firefox_profile=profile, options=options)
            except Exception as e:
                logging.error(e)

            # NOTE:エクステンションの追加
            types = Ext_Type.split(",")
            file_list = []
            for ext in types:
                file_list.extend(f for f in glob.glob(os.path.join(Ext_RootPath, '*.' + ext)))
            for Ext_Path in file_list:
                try:
                    self.driver.install_addon(Ext_Path, temporary=True)
                    logging.info("拡張機能{}が読み込まれました".format(os.path.basename(Ext_Path)))
                except Exception as e:
                    logging.error(e)

        elif self.opt == "Chromium":
            browserPath = self.LoadConfig['Chromium']['prog']
            WebDriver = self.LoadConfig['Chromium']['webdriver']
            Ext_RootPath = self.LoadConfig['Chromium']['ext_path']
            Ext_Type = self.LoadConfig['Chromium']['type']

            options = Options()
            options.binary_location = browserPath
            # FIXME:headlessモードで証明書エラーを回避できないver75でoptionとcapabilitiesが併用できていない気がする
            # --headlessで動かすために必要なオプション
            # options.add_argument('--headless')
            options.add_argument('--disable-gpu')
            options.add_argument('--no-sandbox')
            # エラーの許容
            options.add_argument('--ignore-certificate-errors')
            # options.add_argument('--allow-runnig-insecure-content')
            # options.add_argument('--allow-insecure-localhost')
            # options.add_argument('--disable-web-security')
            # options.add_experimental_option('w3c',False)
            # UA
            # options.add_argument('--user-agent=hogehoge')
            # options.add_argument('--incognito')
            options.add_argument('--disable-desktop-notifications')
            options.add_argument('--disable-popup-blocking')
            # 証明書エラー回避
            capabilities = DesiredCapabilities.CHROME.copy()
            capabilities['acceptSslCerts'] = True
            capabilities['acceptInsecureCerts'] = True

            types = Ext_Type.split(",")
            file_list = []
            for ext in types:
                file_list.extend(f for f in glob.glob(
                    os.path.join(Ext_RootPath, '*.' + ext)))
            for Ext_Path in file_list:
                try:
                    options.add_extension(Ext_Path)
                    logging.info("拡張機能{}が読み込まれました".format(os.path.basename(Ext_Path)))
                except Exception as e:
                    logging.error(e)
                    sys.exit(1)
            try:
                self.driver = webdriver.Chrome(executable_path=WebDriver, chrome_options=options, desired_capabilities=capabilities)

            except Exception as e:
                logging.error(e)
                sys.exit(1)
            
        logging.info('ブラウザ{}が選択されました。'.format(self.opt))

    def tearDown(self):
        self.driver.quit()

    @classmethod
    def tearDownClass(cls):
        logging.info("+++終了")

    def test_search_dom(self):

        logging.info("+++テスト実行")

        for _s in self.Url_List:
            _x = re.sub("\\D", "", _s)
            _url = self.LoadConfig[_s]["url"]
            logging.info("URL:{}".format(_url))
            
            self.driver.get(_url)
            # NOTE:idatenログイン画面に自動遷移するため読み込みを待つtimesleep無しでもいける
            if self.driver.current_url == self.Idaten_Url:
                try:
                    WebDriverWait(self.driver, 30).until(EC.presence_of_all_elements_located((By.CLASS_NAME, 'login_btn')))
                    self.driver.find_element_by_name("loginId").click()
                    self.driver.find_element_by_name("loginId").send_keys(self.Idaten_User)
                    self.driver.find_element_by_name("password").click()
                    self.driver.find_element_by_name("password").send_keys(self.Idaten_Pass)
                    self.driver.find_element_by_class_name("login_btn").click()
                except Exception as e:
                    logging.error(e)

            # NOTE:2回目以降はログイン画面が出てこないので、driver.current_urlで分岐する必要がない
            try:
                WebDriverWait(self.driver, 30).until(EC.presence_of_all_elements_located((By.ID, 'submitButton')))
                self.driver.find_element_by_name("j_username").click()
                self.driver.find_element_by_name("j_username").send_keys(self.Qrader_User)
                self.driver.find_element_by_name("j_password").click()
                self.driver.find_element_by_name("j_password").send_keys(self.Qrader_Pass)
                self.driver.find_element_by_id("submitButton").click()
            except Exception as e:
                logging.error(e)
            
            logging.info("+++ログイン完了")


            if funcs.siemType(_url)[1] == "7.3.1":           
                try:
                    WebDriverWait(self.driver, 30).until(EC.presence_of_all_elements_located((By.XPATH, '/html/body/header/div[1]/span')))
                    toptext = self.driver.find_element_by_class_name("OEMHide").text
                    favspane = self.driver.find_element_by_class_name('sy-header__favourites').get_attribute('style')
                    rgb = self.driver.find_element_by_class_name("OEMHide").find_element_by_tag_name("span").get_attribute('style')
                except Exception as e:
                    logging.error(e)
                logging.info("==================================================")
                logging.info('class = sy-header__favourites : {}'.format(funcs.rgbHex(favspane)))
                logging.info('id = topNavProductName :{} - <span style=" {} "> {} </span>;'.format(toptext,funcs.rgbHex(rgb),funcs.siemType(_url)[0]))
                
            elif funcs.siemType(_url)[1] == "7.2.8":

                navids = ["DASHBOARD", "SEM", "EVENTVIEWER", "FLOWVIEWER","ASSETS", "REPORTS", "ADMIN"]

                try:
                    # XXX:全ての要素が現れるまでwaitの場合はcssの取得に失敗するので、extensionの色付け読み込みを待つ指定をする
                    WebDriverWait(self.driver, 30).until(EC.presence_of_all_elements_located((By.XPATH, '/html/body/div[2]/div[1]/span')))
                    # WebDriverWait(driver,15).until(EC.visibility_of_all_elements_located((By.ID,'topNavProductName')))
                    toptext = self.driver.find_element_by_class_name("OEMHide").text
                    rgb = self.driver.find_element_by_class_name("OEMHide").find_element_by_tag_name("span").get_attribute('style')
                except Exception as e:
                    # NOTE:タイトルの色付けが適用されているかどうかを取得基準にする
                    logging.error(e)

                logging.info('apptext = {}'.format(toptext))
                logging.info('id = topNavProductName :{} - <span style= "{} "> {} </span>;'.format(toptext,funcs.rgbHex(rgb),funcs.siemType(_url)[0]))
                logging.info("==================================================")

                navtemp = collections.OrderedDict()

                for nav in navids:
                    navid = "TAB_" + nav
                    tab_dashboard = self.driver.find_element_by_id("topNavLayout").find_element_by_id("nav").find_element_by_id(navid).get_attribute('style')
                    navtemp[navid] = tab_dashboard

                for k, v in navtemp.items():
                    logging.info('id={} : style={}'.format(k, funcs.rgbHex(v)))

            logging.info("==================================================")
            logging.info("")

if __name__ == "__main__":
    logging.config.fileConfig(r"logging/logging.config")
    # NOTE:デフォルトでsys.exit()が呼ばれてしまうため
    unittest.main(exit=False)
