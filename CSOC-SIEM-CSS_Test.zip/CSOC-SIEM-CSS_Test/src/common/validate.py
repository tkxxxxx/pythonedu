'''
NOTE:validatetion用
'''

import os
import sys
from common.funcs import *

def config_validation(config):
    # NOTE:コンフィグチェック適当です

    flag_error = False

    opt = config['env']['browser']
    hdl = config['env']['headless']

    if not opt in ("Firefox", "Chromium"):
        flag_error = True
        print("FirefoxもしくはChromiumを指定してください")
        sys.exit(1)

    if opt == "Firefox":
        browserPath = config['Firefox']['prog']
        WebDriver = config['Firefox']['webdriver']
        Ext_RootPath = config['Firefox']['ext_path']
        Ext_Type = config['Firefox']['type']

        if browserPath == "":
            print("ブラウザパスが空欄です")
            flag_error = True

        if not os.path.exists(browserPath):
            print("ブラウザパスが存在しません")
            flag_error = True

        if WebDriver == "":
            print("webdriverパスが空欄です")
            flag_error = True

        if not os.path.exists(WebDriver):
            print("webdriverパスが存在しません")
            flag_error = True

        if Ext_RootPath == "":
            print("拡張機能の指定フォルダが空欄です")
            flag_error = True

        if not os.path.exists(Ext_RootPath):
            print("拡張機能の指定フォルダが存在しません")
            flag_error = True

        if Ext_Type == "":
            print("拡張機能タイプの拡張子が空欄です")
            flag_error = True

    if opt == "Chromium":
        browserPath = config['Chromium']['prog']
        WebDriver = config['Chromium']['webdriver']
        Ext_RootPath = config['Chromium']['ext_path']
        Ext_Type = config['Chromium']['type']

        if browserPath == "":
            print("ブラウザパスが空欄です")
            flag_error = True

        if not os.path.exists(browserPath):
            print("ブラウザパスが存在しません")
            flag_error = True

        if WebDriver == "":
            print("webdriverパスが空欄です")
            flag_error = True

        if not os.path.exists(WebDriver):
            print("webdriverパスが存在しません")
            flag_error = True

        if Ext_RootPath == "":
            print("拡張機能の指定フォルダが空欄です")
            flag_error = True

        if not os.path.exists(Ext_RootPath):
            print("拡張機能の指定フォルダが存在しません")
            flag_error = True

        if Ext_Type == "":
            print("拡張機能タイプの拡張子が空欄です")
            flag_error = True

    Idaten_User = config['Idaten']['user']
    if Idaten_User == "":
        print("idatenユーザーが空欄です")
        flag_error = True

    Idaten_Pass = decoded(config['Idaten']['password'])
    if Idaten_Pass == "":
        print("idatenパスワードが空欄です")
        flag_error = True

    Qrader_User = config['Qrader']['user']
    if Qrader_User == "":
        print("Qraderユーザーが空欄です")
        flag_error = True

    Qrader_Pass = decoded(config['Qrader']['password'])
    if Qrader_Pass == "":
        print("Qraderパスワードが空欄です")
        flag_error = True

    url_List = [lst for lst in config if "Test" in lst]
    for sec in url_List:
        target_url = config[sec]['url']
        if target_url == "":
            print("ターゲットURLが空欄です")
            flag_error = True

    if flag_error:
        sys.exit(1)
