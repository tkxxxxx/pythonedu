'''
NOTE:configparserの情報取得
'''

import os
import sys
import collections
import datetime
import time
import re
import base64
import binascii
import configparser


class EnvInterpolation(configparser.BasicInterpolation):
    # NOTE:環境変数補間のための拡張'''

    def before_get(self, parser, section, option, value, defaults):
        return os.path.expandvars(value)

def loadInitFile():

    file = r'..\bin\csoc-siem.ini'
    path = os.path.join(os.path.dirname(__file__), file)
    if not os.path.isfile(path):
        print("設定ファイル %s が見つかりません".format(path))
        sys.exit(1)
    # ファイルの読み取り
    config = configparser.ConfigParser(interpolation=EnvInterpolation())
    config.read(path, 'utf-8')
    return config


def rgbHex(tag):
    # NOTE:hexgenerater rgb(255, 255, 0) ⇒ #FFFF00
    rgblist = re.findall(r'rgb\(\d+,\s*\d+,\s*\d+\)', tag)
    colorsets = []
    for rgb in rgblist:
        r, g, b = map(int, re.search(
            r'rgb\((\d+),\s*(\d+),\s*(\d+)', rgb).groups())
        colorsets.append('#{:02X}{:02X}{:02X}'.format(r, g, b))
    for color in colorsets:
        tag = re.sub(r'rgb\(\d+,\s*\d+,\s*\d+\)', color, tag, 1)
    return tag


def siemType(url):

    tmp = []
    svrname = re.split("[/.]", url)[2]
    tmp.append(svrname)
    if re.search(r"/csoc-siem-console1130", url):
        tmp.extend(["7.2.8", 'topNavLayout'])
    else:
        tmp.extend(["7.3.1", 'nav'])
    return tmp
    '''
    ['csoc-basic-siem-console1133-stg', '7.3.1']
    ['csoc-siem-console4430-dev', '7.3.1']
    ['csoc-siem-console1130-stg', '7.2.8']
    ['csoc-siem-console1130-001', '7.2.8']
    ['csoc-siem-console1130-002', '7.2.8']
    ['csoc-siem-console1130-003', '7.2.8']
    ['csoc-siem-console1130-004', '7.2.8']
    ['csoc-siem-console1133-005', '7.3.1']
    ['csoc-siem-console1133-006', '7.3.1']
    ['csoc-basic-siem-console1133-stg', '7.3.1']
    ['csoc-basic-siem-console1133-001', '7.3.1']
    '''

def decoded(passwd):
    dec = base64.urlsafe_b64decode(passwd + '=' * (-len(passwd) % 4))
    return dec.decode('utf-8')

def getNowTime():
    return datetime.datetime.now().strftime("%Y%m%d%H%M%S")
