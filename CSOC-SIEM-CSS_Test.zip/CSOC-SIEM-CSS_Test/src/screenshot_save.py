'''
# NOTE:トップ画面のスクリーンショットをlogging配下に保存する
'''

from common import funcs
from common import validate
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver import Firefox, FirefoxOptions
from selenium.webdriver.chrome.options import Options
# 待機時間の設定
from selenium.webdriver.support.ui import WebDriverWait
# 次にクリックしたページの状態をチェックする
from selenium.webdriver.support import expected_conditions as EC
# htmlタグの取得
from selenium.webdriver.common.by import By
# GUI操作
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.color import Color
import unittest
import os
import collections
import re
import glob
import logging
import logging.config


def screen_save():

    LoadConfig = funcs.loadInitFile()
    opt = LoadConfig['env']['browser']
    hdl = LoadConfig['env']['headless']

    Idaten_User = LoadConfig['Idaten']['user']
    Idaten_Pass = funcs.decoded(LoadConfig['Idaten']['password'])
    Idaten_Url = LoadConfig['Idaten']['url']
    Qrader_User = LoadConfig['Qrader']['user']
    Qrader_Pass = funcs.decoded(LoadConfig['Qrader']['password'])

    # NOTE:testurllist
    Url_List = [s for s in LoadConfig if "Test" in s]

    if opt == "Firefox":
        browserPath = LoadConfig['Firefox']['prog']
        WebDriver = LoadConfig['Firefox']['webdriver']
        Ext_RootPath = LoadConfig['Firefox']['ext_path']
        Ext_Type = LoadConfig['Firefox']['type']
        # NOTE:SOC環境におけるFirefoxの標準プロファイル生成
        profile = webdriver.FirefoxProfile()
        profile.set_preference('security.enterprise_roots.enabled', 'true')
        profile.set_preference('xpinstall.signatures.required', 'false')
        profile.set_preference('security.enterprise_roots.enabled', 'true')
        profile.set_preference('general.config.filename', 'csoc.cfg')
        profile.set_preference('general.config.vendor', 'csoc')
        profile.set_preference('general.config.obscure_value', 0)
        # NOTE:証明書の警告を無視する
        profile.accept_untrusted_certs = True
        profile.assume_untrusted_cert_issuer = False

        options = FirefoxOptions()

        if hdl:
            options.add_argument('-headless')

        try:
            driver = webdriver.Firefox(service_log_path=os.path.devnull, firefox_binary=browserPath,
                                            executable_path=WebDriver, firefox_profile=profile, options=options)
        except Exception as e:
            logging.error(e)

        # NOTE:エクステンションの追加
        types = Ext_Type.split(",")
        file_list = []
        for ext in types:
            file_list.extend(f for f in glob.glob(
                os.path.join(Ext_RootPath, '*.' + ext)))
        for Ext_Path in file_list:
            try:
                driver.install_addon(Ext_Path, temporary=True)
                print("拡張機能{}が読み込まれました".format(os.path.basename(Ext_Path)))
            except Exception as e:
                logging.error(e)

    elif opt == "Chromium":
        browserPath = LoadConfig['Chromium']['prog']
        WebDriver = LoadConfig['Chromium']['webdriver']
        Ext_RootPath = LoadConfig['Chromium']['ext_path']
        Ext_Type = LoadConfig['Chromium']['type']

        options = Options()
        options.binary_location = browserPath
        '''FIXME:headlessモードで証明書エラーを回避できないver75でoptionとcapabilitiesが併用できていない気がする'''
        # --headlessで動かすために必要なオプション
        # options.add_argument('--headless')
        options.add_argument('--disable-gpu')
        options.add_argument('--no-sandbox')
        # エラーの許容
        options.add_argument('--ignore-certificate-errors')
        # options.add_argument('--allow-runnig-insecure-content')
        # options.add_argument('--allow-insecure-localhost')
        # options.add_argument('--disable-web-security')
        # options.add_experimental_option('w3c',False)
        # UA
        # options.add_argument('--user-agent=hogehoge')
        # options.add_argument('--incognito')
        options.add_argument('--disable-desktop-notifications')
        options.add_argument('--disable-popup-blocking')
        #　証明書エラー回避
        capabilities = DesiredCapabilities.CHROME.copy()
        capabilities['acceptSslCerts'] = True
        capabilities['acceptInsecureCerts'] = True

        types = Ext_Type.split(",")
        file_list = []
        for ext in types:
            file_list.extend(f for f in glob.glob(
                os.path.join(Ext_RootPath, '*.' + ext)))
        for Ext_Path in file_list:
            try:
                options.add_extension(Ext_Path)
                print("拡張機能{}が読み込まれました".format(os.path.basename(Ext_Path)))
            except Exception as e:
                logging.error(e)
                sys.exit(1)
        try:
            driver = webdriver.Chrome(
                executable_path=WebDriver, chrome_options=options, desired_capabilities=capabilities)

        except Exception as e:
            logging.error(e)
            sys.exit(1)

    print('ブラウザ{}が選択されました。'.format(opt))


    for _s in Url_List:
        _x = re.sub("\\D", "", _s)
        _url = LoadConfig[_s]["url"]
        print("URL:{}".format(_url))

        driver.get(_url)
        # NOTE:idatenログイン画面に自動遷移するため読み込みを待つtimesleep無しでもいける
        if driver.current_url == Idaten_Url:
            try:
                WebDriverWait(driver, 30).until(
                    EC.presence_of_all_elements_located((By.CLASS_NAME, 'login_btn')))
                driver.find_element_by_name("loginId").click()
                driver.find_element_by_name(
                    "loginId").send_keys(Idaten_User)
                driver.find_element_by_name("password").click()
                driver.find_element_by_name(
                    "password").send_keys(Idaten_Pass)
                driver.find_element_by_class_name("login_btn").click()
            except Exception as e:
                print(e)

        # NOTE:2回目以降はログイン画面が出てこないので、driver.current_urlで分岐する必要がない
        try:
            WebDriverWait(driver, 30).until(EC.presence_of_all_elements_located((By.ID, 'submitButton')))
            driver.find_element_by_name("j_username").click()
            driver.find_element_by_name("j_username").send_keys(Qrader_User)
            driver.find_element_by_name("j_password").click()
            driver.find_element_by_name("j_password").send_keys(Qrader_Pass)
            driver.find_element_by_id("submitButton").click()
        except Exception as e:
            print(e)

        print("+++ログイン完了")

        if funcs.siemType(_url)[1] == "7.3.1":
            try:
                WebDriverWait(driver, 30).until(EC.presence_of_all_elements_located((By.XPATH, '/html/body/header/div[1]/span')))
                filename = funcs.getNowTime()+"_"+funcs.siemType(_url)[0]+".png"
                driver.save_screenshot(os.path.join("logging",filename))
            except Exception as e:
                print(e)

        elif funcs.siemType(_url)[1] == "7.2.8":


            try:
                # XXX:全ての要素が現れるまでwaitの場合はcssの取得に失敗するので、extensionの色付け読み込みを待つ指定をする
                WebDriverWait(driver, 30).until(EC.presence_of_all_elements_located((By.XPATH, '/html/body/div[2]/div[1]/span')))
                # WebDriverWait(driver,15).until(EC.visibility_of_all_elements_located((By.ID,'topNavProductName')))
                filename = funcs.getNowTime()+"_"+funcs.siemType(_url)[0]+".png"
                driver.save_screenshot(os.path.join("logging",filename))
            except Exception as e:
                print(e)

    driver.close()


if __name__ == "__main__":
    screen_save()
