# CSOC-SIEM-CSS_Test
## 概要

WebExtensionのCSOC-SIEM-CSSテスト用に作成。  
python3.5とそのライブラリseleniumを利用しエクステンションのインストールから動的に挿入されるhtmlタグの情報を取得する。  

### 設定ファイルのパラメータの説明
bin/csoc-siem.iniの設定情報

|section|パラメータ|説明|必須|
|------|-----|----|----|
|[env]|browser|ChromiumかFirefoxを指定する|✔|
|[env]|headless|headlessモードの利用有無、Chromiumでは未対応||
|%browser%|prog|ブラウザ内のプログラムファイルを指定する|✔|
|%browser%|webdriver|WebDriverを指定する。msiによって配布済|✔|
|%browser%|ext_path|エクステンションが格納されているフォルダを指定する|✔|
|%browser%|type|エクステンションの拡張子を指定する。複数指定可能|✔|
|[Idaten]|user|idatenのユーザーIDをセットする|✔|
|[Idaten]|password|idatenのパスワードをbase64にエンコード後セットする|✔|
|[Idaten]|url|idatenログイン認証のURL|✔|
|[Qrader]|user|QraderのユーザーIDをセットする|✔|
|[Qrader]|password|Qraderのパスワードをbase64にエンコード後セットする|✔|
|[Test?]|url|テストで利用するURLをセットする。セクションごとに指定する|✔|

※Firefoxにも対応可

|プログラム|説明|
|------|-----|
|test_csoc-siem.py|エクステンションを単一プログラムとみなしてunittestテストを行う|
|screenshot_save.py|エクステンションが読み込まれた後のトップページのスクリーンショットを取得する|

## 実行方法

```
python test_csoc-siem.py
python screenshot_save.py
```